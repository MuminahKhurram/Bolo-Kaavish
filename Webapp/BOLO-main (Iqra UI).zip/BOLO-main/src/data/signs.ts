// import { Sign, Category } from '../types';

// export const categories: Category[] = [
//   { id: 'alphabet', name: 'Alphabet', description: 'Learn to sign the alphabet' },
//   { id: 'numbers', name: 'Numbers', description: 'Learn to sign numbers' },
//   { id: 'colors', name: 'Colors', description: 'Learn to sign colors' },
//   { id: 'greetings', name: 'Greetings', description: 'Common greetings and phrases' },
// ];

// export const signs: Sign[] = [
//   { id: 'a', name: 'A', category: 'alphabet', videoUrl: '/videos/alphabet/a.mp4' },
//   { id: 'b', name: 'B', category: 'alphabet', videoUrl: '/videos/alphabet/b.mp4' },
//   { id: 'c', name: 'C', category: 'alphabet', videoUrl: '/videos/alphabet/c.mp4' },
//   { id: '1', name: 'One', category: 'numbers', videoUrl: '/videos/numbers/1.mp4' },
//   { id: '2', name: 'Two', category: 'numbers', videoUrl: '/videos/numbers/2.mp4' },
//   { id: '3', name: 'Three', category: 'numbers', videoUrl: '/videos/numbers/3.mp4' },
// ];

import { Sign, Category } from '../types';

export const categories: Category[] = [
  { id: 'alphabet', name: 'Alphabet', description: 'Learn to sign the alphabet' },
  { id: 'colors', name: 'Colors', description: 'Learn to sign colors' },
  { id: 'fruits', name: 'Fruits', description: 'Learn to sign fruits' },
];

export const signs: Sign[] = [
  // Alphabet Signs
  { id: 'a', name: 'A', category: 'alphabet', videoUrl: '/videos/a.mp4' },
  { id: 'b', name: 'B', category: 'alphabet', videoUrl: '/videos/b.mp4' },
  { id: 'c', name: 'C', category: 'alphabet', videoUrl: '/videos/c.mp4' },
  { id: 'd', name: 'D', category: 'alphabet', videoUrl: '/videos/d.mp4' },
  { id: 'e', name: 'E', category: 'alphabet', videoUrl: '/videos/e.mp4' },
  { id: 'f', name: 'F', category: 'alphabet', videoUrl: '/videos/f.mp4' },
  { id: 'g', name: 'G', category: 'alphabet', videoUrl: '/videos/g.mp4' },
  { id: 'h', name: 'H', category: 'alphabet', videoUrl: '/videos/h.mp4' },
  { id: 'i', name: 'I', category: 'alphabet', videoUrl: '/videos/i.mp4' },

  // Color Signs
  { id: 'black', name: 'Black', category: 'colors', videoUrl: '/videos/black.mp4' },
  { id: 'brown', name: 'Brown', category: 'colors', videoUrl: '/videos/brown.mp4' },
  { id: 'blue', name: 'Blue', category: 'colors', videoUrl: '/videos/blue.mp4' },
  { id: 'gold', name: 'Gold', category: 'colors', videoUrl: '/videos/gold.mp4' },

  // Fruit Signs
  { id: 'apricot', name: 'Apricot', category: 'fruits', videoUrl: '/videos/apricot.mp4' },
  { id: 'banana', name: 'Banana', category: 'fruits', videoUrl: '/videos/banana.mp4' },
  { id: 'berry', name: 'Berry', category: 'fruits', videoUrl: '/videos/berry.mp4' },
  { id: 'cherry', name: 'Cherry', category: 'fruits', videoUrl: '/videos/cherry.mp4' },
  { id: 'coconut', name: 'Coconut', category: 'fruits', videoUrl: '/videos/coconut.mp4' },
  { id: 'date', name: 'Date', category: 'fruits', videoUrl: '/videos/date.mp4' },
];