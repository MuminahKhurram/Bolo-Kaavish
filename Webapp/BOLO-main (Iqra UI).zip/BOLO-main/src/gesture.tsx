import React, { useState } from 'react';
import axios from 'axios';

const GestureRecognition = () => {
    const [image, setImage] = useState(null);
    const [prediction, setPrediction] = useState('');
    const [confidence, setConfidence] = useState('');

    // Handle file input change
    const handleFileChange = (e) => {
        const file = e.target.files[0];
        if (file) {
            setImage(file);
        }
    };

    // Handle form submission to send image to the Flask backend
    const handleSubmit = async (e) => {
        e.preventDefault();
        
        if (!image) {
            alert('Please upload an image.');
            return;
        }

        const formData = new FormData();
        formData.append('frame', image);

        try {
            // Send the image to Flask API for prediction
            const response = await axios.post('http://localhost:5000/predict', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                },
            });

            // Handle prediction response
            const { prediction, confidence } = response.data;
            setPrediction(prediction);
            setConfidence(confidence);
        } catch (error) {
            console.error('Error during prediction:', error);
            alert('Error during prediction');
        }
    };

    return (
        <div>
            <h1>Gesture Recognition</h1>
            <form onSubmit={handleSubmit}>
                <input type="file" onChange={handleFileChange} />
                <button type="submit">Predict Gesture</button>
            </form>
            
            {prediction && (
                <div>
                    <h2>Prediction: {prediction}</h2>
                    <h3>Confidence: {confidence}</h3>
                </div>
            )}
        </div>
    );
};

export default GestureRecognition;
