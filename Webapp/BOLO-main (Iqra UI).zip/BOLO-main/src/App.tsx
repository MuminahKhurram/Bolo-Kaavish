import { useState } from 'react';
import Home from './components/Home';
import Categories from './components/Categories';
import SignList from './components/SignList';
import SignViewer from './components/SignViewer';
import PracticeSession from './components/PracticeSession';

export default function App() {
  const [currentView, setCurrentView] = useState('home');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedSign, setSelectedSign] = useState('');

  const renderView = () => {
    switch (currentView) {
      case 'home':
        return <Home onNavigate={() => setCurrentView('categories')} />;
      case 'categories':
        return (
          <Categories
            onSelectCategory={(category) => {
              setSelectedCategory(category);
              setCurrentView('signList');
            }}
            onBack={() => setCurrentView('home')}
          />
        );
      case 'signList':
        return (
          <SignList
            category={selectedCategory}
            onSelectSign={(sign) => {
              setSelectedSign(sign);
              setCurrentView('viewer');
            }}
            onBack={() => setCurrentView('categories')}
          />
        );
      case 'viewer':
        return (
          <SignViewer
            sign={selectedSign}
            onBack={() => setCurrentView('signList')}
            onPractice={() => setCurrentView('practice')}
          />
        );
      case 'practice':
        return (
          <PracticeSession
            sign={selectedSign}
            onBack={() => setCurrentView('viewer')}
            ondoubBack={() => setCurrentView('signList')}
          />
        );
      default:
        return <Home onNavigate={() => setCurrentView('categories')} />;
    }
  };

  return (
    <div style={{ maxWidth: '600px', margin: '0 auto', padding: '20px' }}>
      {renderView()}
    </div>
  );
}








// import { useState } from 'react';
// import Home from './components/Home';
// import Categories from './components/Categories';
// import SignList from './components/SignList';
// import SignViewer from './components/SignViewer';
// import PracticeSession from './components/PracticeSession';
// import RandomPractice from './components/RandomPractice';

// export default function App() {
//   const [currentView, setCurrentView] = useState('home');
//   const [selectedCategory, setSelectedCategory] = useState('');
//   const [selectedSign, setSelectedSign] = useState('');

//   const renderView = () => {
//     switch (currentView) {
//       case 'home':
//         return <Home onNavigate={() => setCurrentView('categories')} onPractice={() => setCurrentView('randomPractice')} />;
//       case 'categories':
//         return (
//           <Categories
//             onSelectCategory={(category) => {
//               setSelectedCategory(category);
//               setCurrentView('signList');
//             }}
//           />
//         );
//       case 'signList':
//         return (
//           <SignList
//             category={selectedCategory}
//             onSelectSign={(sign) => {
//               setSelectedSign(sign);
//               setCurrentView('viewer');
//             }}
//             onBack={() => setCurrentView('categories')}
//           />
//         );
//       case 'viewer':
//         return (
//           <SignViewer
//             sign={selectedSign}
//             onBack={() => setCurrentView('signList')}
//             onPractice={() => setCurrentView('practice')}
//           />
//         );
//       case 'practice':
//         return (
//           <PracticeSession
//             sign={selectedSign}
//             onBack={() => setCurrentView('viewer')}
//           />
//         );
//       case 'randomPractice':
//         return (
//           <RandomPractice
//             onFinish={() => setCurrentView('home')}
//           />
//         );
//       default:
//         return <Home onNavigate={() => setCurrentView('categories')} onPractice={() => setCurrentView('randomPractice')} />;
//     }
//   };

//   return (
//     <div style={{ maxWidth: '600px', margin: '0 auto', padding: '20px' }}>
//       {renderView()}
//     </div>
//   );
// }
