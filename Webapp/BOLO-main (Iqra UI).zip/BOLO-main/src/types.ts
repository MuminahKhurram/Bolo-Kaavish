export interface Sign {
  id: string;
  name: string;
  category: string;
  videoUrl: string;
}

export interface Category {
  id: string;
  name: string;
  description: string;
}