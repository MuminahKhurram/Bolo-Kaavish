// import React, { useState, useRef } from 'react';
// import axios from 'axios';
// import Webcam from 'react-webcam';

// interface PracticeSessionProps {
//   sign: string;
//   onBack: () => void;
// }

// const sequenceLength = 40; // Number of frames to capture

// export default function PracticeSession({
//   sign,
//   onBack,
// }: PracticeSessionProps) {
//   const webcamRef = useRef<Webcam>(null);  // Use webcamRef for react-webcam
//   const [prediction, setPrediction] = useState<string | null>(null);
//   const [confidence, setConfidence] = useState<number | null>(null);
//   const [isRecording, setIsRecording] = useState(false);
//   const [error, setError] = useState<string | null>(null);

//   const captureFrame = (capturedFrames: Blob[]) => {
//     const video = webcamRef.current?.getScreenshot();  // Get screenshot from react-webcam

//     if (video) {
//       // Convert the base64 image to a Blob
//       fetch(video)
//         .then((res) => res.blob())
//         .then((blob) => {
//           capturedFrames.push(blob);
//         });
//     }
//   };

//   const fetchPrediction = async (frames: Blob[]) => {
//     try {
//       const formData = new FormData();
//       frames.forEach((frame, index) => formData.append(`frame${index}`, frame));
//       console.log('Sending request to backend with frames:', frames.length);

//       const response = await axios.post('http://localhost:5000/predict', formData, {
//         headers: { 'Content-Type': 'multipart/form-data' },
//       });
//       console.log('Backend response:', response.data);  
//       setPrediction(response.data.prediction);
//       setConfidence(response.data.confidence);
//       setError(null);
//     } catch (err) {
//       console.error('Failed to get prediction:', err);
//       setError('Failed to get prediction. Please try again.');
//     }
//   };

//   const startRecording = () => {
//     setIsRecording(true);
//     setPrediction(null);
//     setConfidence(null);
//     setError(null);

//     const capturedFrames: Blob[] = [];
//     const startTime = Date.now();

//     const captureInterval = setInterval(() => {
//       if (capturedFrames.length >= sequenceLength) {
//         clearInterval(captureInterval);
//         setIsRecording(false);
//         fetchPrediction(capturedFrames);
//       } else {
//         captureFrame(capturedFrames);
//       }
//     }, 100);
//   };

//   return (
//     <div className="text-center">
//       <h1 className="text-2xl font-bold mb-5">Practice: {sign.replace('.mp4', '').toUpperCase()}</h1>

//       <Webcam
//         ref={webcamRef}
//         width="640"
//         height="480"
//         screenshotFormat="image/jpeg"
//         videoConstraints={{
//           facingMode: "user",  // Optional: use user-facing camera (front camera)
//         }}
//         className="border-2 border-black mb-5"
//       />

//       <button
//         onClick={startRecording}
//         disabled={isRecording}
//         className={`px-4 py-2 text-white font-bold rounded-lg ${
//           isRecording ? 'bg-gray-400' : 'bg-blue-500 hover:bg-blue-600'
//         }`}
//       >
//         {isRecording ? 'Recording...' : 'Start Recording'}
//       </button>

//       {prediction && (
//         <div className="mt-5">
//           <h2 className="text-xl font-bold">Prediction: {prediction}</h2>
//           <p>Confidence: {(confidence! * 100).toFixed(2)}%</p>
//         </div>
//       )}

//       {error && (
//         <div className="text-red-500 mt-5">
//           <p>{error}</p>
//         </div>
//       )}

//       {prediction && (
//         <div className="mt-5">
//           <h2 className="text-xl font-bold">
//             {prediction.toLowerCase() === sign.replace('.mp4', '').toLowerCase() ? 'Congrats! You got it right!' : 'Sorry, try again.'}
//           </h2>
//           <p>Confidence: {(confidence! * 100).toFixed(2)}%</p>

//           <div className="mt-4 flex gap-4 justify-center">
//             <button
//               onClick={() => {
//                 // Reset or retry logic
//                 setIsRecording(false);
//                 setPrediction(null);
//                 setConfidence(null);
//                 setError(null);
//               }}
//               className="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600"
//             >
//               {prediction.toLowerCase() === sign.replace('.mp4', '').toLowerCase() ? 'Practice Again' : 'Try Another Sign'}
//             </button>

//             <button
//               onClick={onBack}
//               className="px-4 py-2 bg-gray-300 rounded-lg hover:bg-gray-400"
//             >
//               Back to Video
//             </button>
//           </div>
//         </div>
//       )}


//       <div className="mt-5 flex gap-4 justify-center">
//         <button
//           onClick={onBack}
//           className="px-4 py-2 bg-gray-300 rounded-lg hover:bg-gray-400"
//         >
//           Back
//         </button>
//       </div>
//     </div>
//   );
// }





import React, { useState, useRef } from 'react';
import axios from 'axios';
import Webcam from 'react-webcam';

interface PracticeSessionProps {
  sign: string;
  onBack: () => void;
  ondoubBack: () => void;
}

const sequenceLength = 40; // Number of frames to capture

export default function PracticeSession({ sign, onBack, ondoubBack }: PracticeSessionProps) {
  const webcamRef = useRef<Webcam>(null);
  const [prediction, setPrediction] = useState<string | null>(null);
  const [confidence, setConfidence] = useState<number | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [progress, setProgress] = useState<number>(0);

  const captureFrame = (capturedFrames: Blob[]) => {
    const video = webcamRef.current?.getScreenshot();
    if (video) {
      fetch(video)
        .then((res) => res.blob())
        .then((blob) => {
          capturedFrames.push(blob);
        });
    }
  };

  const fetchPrediction = async (frames: Blob[]) => {
    try {
      const formData = new FormData();
      frames.forEach((frame, index) => formData.append(`frame${index}`, frame));
      console.log('Sending request to backend with frames:', frames.length);

      const response = await axios.post('http://localhost:5000/predict', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      console.log('Backend response:', response.data);
      setPrediction(response.data.prediction);
      setConfidence(response.data.confidence);
      setError(null);
    } catch (err) {
      console.error('Failed to get prediction:', err);
      setError('Failed to get prediction. Please try again.');
    }
  };

  const startRecording = () => {
    setIsRecording(true);
    setPrediction(null);
    setConfidence(null);
    setError(null);
    setProgress(0);

    const capturedFrames: Blob[] = [];
    const captureInterval = setInterval(() => {
      if (capturedFrames.length >= sequenceLength) {
        clearInterval(captureInterval);
        setIsRecording(false);
        fetchPrediction(capturedFrames);
      } else {
        captureFrame(capturedFrames);
        setProgress(((capturedFrames.length + 1) / sequenceLength) * 100);
      }
    }, 100);
  };

  return (
    <div
      style={{
        backgroundColor: '#fff',
        padding: '20px',
        borderRadius: '10px',
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
        maxWidth: '800px',
        margin: '20px auto',
        textAlign: 'center',
      }}
    >
      <h1 style={{ fontSize: '24px', marginBottom: '20px' }}>
        Practice: {sign.replace('.mp4', '').toUpperCase()}
      </h1>

      <div style={{ marginBottom: '20px' }}>
        <Webcam
          ref={webcamRef}
          width="100%"
          height="100%"
          screenshotFormat="image/jpeg"
          videoConstraints={{ facingMode: 'user' }}
          style={{
            border: '2px solid #000',
            borderRadius: '8px',
            marginBottom: '20px',
          }}
        />
      </div>

      {isRecording && (
        <div style={{ marginBottom: '20px', width: '100%' }}>
          <div
            style={{
              backgroundColor: '#F4A460',
              height: '10px',
              borderRadius: '5px',
              width: `${progress}%`,
            }}
          ></div>
        </div>
      )}

      <button
        onClick={startRecording}
        disabled={isRecording}
        style={{
          padding: '10px 20px',
          backgroundColor: isRecording ? '#ddd' : '#F4A460',
          border: 'none',
          borderRadius: '5px',
          color: 'white',
          cursor: isRecording ? 'not-allowed' : 'pointer',
          marginBottom: '20px',
        }}
      >
        {isRecording ? 'Recording...' : 'Start Recording'}
      </button>

      {prediction && (
        <div
          style={{
            marginBottom: '20px',
            padding: '10px',
            borderRadius: '5px',
            border: 'none',
          }}
        >
          <h2
            style={{
              fontSize: '20px',
              fontWeight: 'bold',
              // color: '#007BFF',
              color: '#F4A460',
              marginBottom: '10px',
            }}
          >
            {prediction.toLowerCase() === sign.replace('.mp4', '').toLowerCase()
              ? 'Congrats! You got it right!'
              : 'Try Again!'}
          </h2>
          <p style={{ fontSize: '14px', color: '#888' }}>Predicted Sign: {prediction}</p>
          <p style={{ fontSize: '14px', color: '#888' }}>Confidence: {(confidence! * 100).toFixed(2)}%</p>
        </div>
      )}

      {error && (
        <div style={{ color: 'red', marginBottom: '20px' }}>
          <p>{error}</p>
        </div>
      )}

      <div style={{ display: 'flex', justifyContent: 'center', gap: '10px' }}>
        {/* <button
          onClick={() => {
            setIsRecording(false);
            setPrediction(null);
            setConfidence(null);
            setError(null);
          }}
          style={{
            padding: '10px 20px',
            backgroundColor: '#ddd',
            border: 'none',
            borderRadius: '5px',
            cursor: 'pointer',
            marginBottom: '20px',
          }}
        >
          {prediction?.toLowerCase() === sign.replace('.mp4', '').toLowerCase()
            ? 'Practice Again'
            : 'Try Another Sign'}
        </button> */}

        <button
          onClick={ondoubBack}
          style={{
            padding: '10px 20px',
            backgroundColor: '#ddd',
            border: 'none',
            borderRadius: '5px',
            cursor: 'pointer',
            marginBottom: '20px',
          }}
        >
          Try Another Sign
        </button>

        <button
          onClick={onBack}
          style={{
            padding: '10px 20px',
            backgroundColor: '#ddd',
            border: 'none',
            borderRadius: '5px',
            cursor: 'pointer',
            marginBottom: '20px',
          }}
        >
          Back to Video
        </button>
      </div>
    </div>
  );
}
