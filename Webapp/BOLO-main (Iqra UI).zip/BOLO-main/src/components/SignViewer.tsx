// interface SignViewerProps {
//   sign: string;
//   onBack: () => void;
//   onPractice: () => void;
// }

// export default function SignViewer({ sign, onBack, onPractice }: SignViewerProps) {
//   return (
//     <div>
//       <header style={{ textAlign: 'center', marginBottom: '20px' }}>
//         <h1 style={{ fontSize: '24px' }}>Learn: {sign.toUpperCase()}</h1>
//       </header>

//       <div style={{ 
//         backgroundColor: '#fff',
//         padding: '20px',
//         borderRadius: '10px',
//         boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
//         marginBottom: '20px'
//       }}>
//         <video
//           src={`/videos/${sign}.mp4`}
//           controls
//           autoPlay
//           loop
//           style={{
//             width: '100%',
//             borderRadius: '8px',
//             marginBottom: '20px'
//           }}
//         />

//         <div style={{ 
//           display: 'flex',
//           gap: '10px',
//           justifyContent: 'space-between'
//         }}>
//           <button
//             onClick={onBack}
//             style={{
//               padding: '10px 20px',
//               backgroundColor: '#ddd',
//               border: 'none',
//               borderRadius: '5px',
//               cursor: 'pointer'
//             }}
//           >
//             Back
//           </button>
//           <button
//             onClick={onPractice}
//             style={{
//               padding: '10px 20px',
//               backgroundColor: '#F4A460',
//               border: 'none',
//               borderRadius: '5px',
//               color: 'white',
//               cursor: 'pointer'
//             }}
//           >
//             Practice Now
//           </button>
//         </div>
//       </div>
//     </div>
//   );
// }
// -------------------------------------------------------------------------------------------------------------------------------

interface SignViewerProps {
  sign: string;
  onBack: () => void;
  onPractice: () => void;
}

export default function SignViewer({ sign, onBack, onPractice }: SignViewerProps) {
  const videoUrl = `http://localhost:5001/api/stream/${sign}`;
  console.log('Video URL being used:', videoUrl);
  return (
    <div>
      <header style={{ textAlign: 'center', marginBottom: '20px' }}>
        <h1 style={{ fontSize: '24px' }}>Learn: {sign.replace('.mp4', '').toUpperCase()}</h1>
      </header> 
      
      <div style={{ 
        backgroundColor: '#fff',
        padding: '20px',
        borderRadius: '10px',
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
        marginBottom: '20px'
      }}>
        {/* Updated src to use the correct streaming endpoint */}
        {/* <video
          src={`http://localhost:5001/api/stream/${sign}`}
          controls
          autoPlay
          loop
          style={{
            width: '100%',
            borderRadius: '8px',
            marginBottom: '20px'
          }}
        /> */}
        <video
          src={`http://localhost:5001/api/stream/${sign}`}
          controls
          autoPlay
          loop
          style={{
            width: '100%',
            borderRadius: '8px',
            marginBottom: '20px',
          }}
          onError={(e) => {
            console.error('Video failed to load:', `http://localhost:5001/api/stream/${sign}`, e);
          }}
        />

        <div style={{ 
          display: 'flex',
          gap: '10px',
          justifyContent: 'space-between'
        }}>
          <button
            onClick={onBack}
            style={{
              padding: '10px 20px',
              backgroundColor: '#ddd',
              border: 'none',
              borderRadius: '5px',
              cursor: 'pointer'
            }}
          >
            Back
          </button>
          <button
            onClick={onPractice}
            style={{
              padding: '10px 20px',
              backgroundColor: '#F4A460',
              border: 'none',
              borderRadius: '5px',
              color: 'white',
              cursor: 'pointer'
            }}
          >
            Practice Now
          </button>
        </div>
      </div>
    </div>
  );
}
