import { useState, useRef } from 'react';
import { useParams, Link } from 'react-router-dom';
import Webcam from 'react-webcam';
import { signs } from '../data/signs';

export default function PracticeMode() {
  const { signId } = useParams<{ signId: string }>();
  const sign = signs.find((s) => s.id === signId);
  const webcamRef = useRef<Webcam>(null);
  const [feedback, setFeedback] = useState<string>('');
  const [showFeedback, setShowFeedback] = useState(false);

  const handleCapture = () => {
    // In a real app, this would integrate with ML model for sign recognition
    const randomFeedback = Math.random() > 0.5 ? 'Good Job!' : 'Try Again!';
    setFeedback(randomFeedback);
    setShowFeedback(true);
  };

  if (!sign) {
    return <div>Sign not found</div>;
  }

  return (
    <div className="max-w-3xl mx-auto">
      <div className="bg-white rounded-lg shadow-sm p-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">
          Practice: {sign.name}
        </h2>
        
        <div className="grid grid-cols-2 gap-4">
          <div>
            <h3 className="text-lg font-medium mb-2">Reference Sign</h3>
            <video
              src={sign.videoUrl}
              controls
              loop
              className="w-full rounded-lg"
            />
          </div>
          
          <div>
            <h3 className="text-lg font-medium mb-2">Your Practice</h3>
            <Webcam
              ref={webcamRef}
              audio={false}
              className="w-full rounded-lg"
            />
          </div>
        </div>

        {showFeedback ? (
          <div className="mt-6 text-center">
            <p className="text-xl font-bold mb-4">{feedback}</p>
            <div className="space-x-4">
              <button
                onClick={() => setShowFeedback(false)}
                className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700"
              >
                Try Again
              </button>
              <Link
                to={`/category/${sign.category}`}
                className="bg-gray-600 text-white px-4 py-2 rounded-md hover:bg-gray-700"
              >
                Back to List
              </Link>
            </div>
          </div>
        ) : (
          <div className="mt-6 text-center">
            <button
              onClick={handleCapture}
              className="bg-indigo-600 text-white px-6 py-3 rounded-md hover:bg-indigo-700 text-lg"
            >
              Check My Sign
            </button>
          </div>
        )}
      </div>
    </div>
  );
}