import { Link } from 'react-router-dom';
import { categories } from '../data/signs';

export default function CategoryGrid() {
  return (
    <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
      {categories.map((category) => (
        <Link
          key={category.id}
          to={`/category/${category.id}`}
          className="block p-6 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow"
        >
          <h3 className="text-lg font-semibold text-gray-900">{category.name}</h3>
          <p className="mt-2 text-sm text-gray-600">{category.description}</p>
        </Link>
      ))}
      
    </div>
  );
}

// import { categories } from '../data/signs'; // Ensure categories are coming from your database or local array

// export default function CategoryGrid({ onSelectCategory }: { onSelectCategory: (id: string) => void }) {
//   return (
//     <div>
//       <h1>Browse Categories</h1>
//       <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
//         {categories.map((category) => (
//           <div
//             key={category.id}
//             style={{ border: '1px solid #ddd', padding: '10px', cursor: 'pointer' }}
//             onClick={() => onSelectCategory(category.id)}
//           >
//             <h2>{category.name}</h2>
//             <p>{category.description}</p>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// }
