interface CategoriesProps {
  onSelectCategory: (category: string) => void;
  onBack: () => void;
}

export default function Categories({ onSelectCategory, onBack }: CategoriesProps) {
  const categories = [
    'Alphabet',
    // 'ABC - Two Handed',
    // 'Urdu Alphabet',
    // 'Numbers',
    // 'Pronouns',
    // 'Verbs',
    // 'Greetings',
    // 'Feelings & Emotions',
    // 'Family & Relations',
    'Colors',
    // 'Health & Body',
    'Fruits'
  ];

  return (
    <div>
      <header style={{ textAlign: 'center', marginBottom: '20px' }}>
        <h1 style={{ fontSize: '24px' }}>Browse Categories</h1>
      </header>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px' }}>
        {categories.map((category) => (
          <div
            key={category}
            onClick={() => onSelectCategory(category)}
            style={{
              backgroundColor: '#F4A460',
              padding: '20px',
              borderRadius: '10px',
              cursor: 'pointer',
              textAlign: 'center'
            }}
          >
            <span style={{ color: 'white' }}>{category}</span>
          </div>
        ))}
      </div>
      <button
            onClick={onBack}
            style={{
              padding: '10px 20px',
              backgroundColor: '#ddd',
              border: 'none',
              borderRadius: '5px',
              cursor: 'pointer',
              marginTop: '20px',
            }}
          >
            Back
      </button>
    </div>
  );
}