// interface SignListProps {
//   category: string;
//   onSelectSign: (sign: string) => void;
//   onBack: () => void;
// }

// export default function SignList({ category, onSelectSign, onBack }: SignListProps) {
//   const signs = Array.from('ABCDEFGHI').map((letter) => ({
//     id: letter.toLowerCase(),
//     label: letter
//   }));

// // export default function SignList({ category, onSelectSign, onBack }: SignListProps) {
// //   const signs = Array.from('a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i').map((letter) => ({
// //     id: letter.toLowerCase(),
// //     label: letter
// //   }));

//   return (
//     <div>
//       <header style={{ textAlign: 'center', marginBottom: '20px' }}>
//         <h1 style={{ fontSize: '24px' }}>{category}</h1>
//       </header>
//       <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px' }}>
//         {signs.map((sign) => (
//           <div
//             key={sign.id}
//             onClick={() => onSelectSign(sign.id)}
//             style={{
//               border: '1px solid #ddd',
//               padding: '20px',
//               borderRadius: '10px',
//               cursor: 'pointer',
//               textAlign: 'center'
//             }}
//           >
//             <span>{sign.label}</span>
//           </div>
//         ))}
//       </div>
//       <button
//         onClick={onBack}
//         style={{
//           marginTop: '20px',
//           padding: '10px 20px',
//           borderRadius: '5px',
//           border: 'none',
//           backgroundColor: '#ddd',
//           cursor: 'pointer'
//         }}
//       >
//         Back
//       </button>
//     </div>
//   );
// }




























// import { useEffect, useState } from 'react';

// interface Video {
//   _id: string;
//   filename: string;
//   category: string;
// }

// interface SignListProps {
//   category: string; // Selected category (e.g., alphabet, colors, fruits)
//   onBack: () => void; // Callback for navigation
// }

// export default function SignList({ category, onBack }: SignListProps) {
//   const [videos, setVideos] = useState<Video[]>([]);
//   const [loading, setLoading] = useState(true);

//   // Fetch videos from the backend API
//   useEffect(() => {
//     const fetchVideos = async () => {
//       try {
//         const response = await fetch(`http://localhost:5001/api/videos/${category}`);
//         const data = await response.json();
//         setVideos(data);
//         setLoading(false);
//       } catch (error) {
//         console.error('Error fetching videos:', error);
//         setLoading(false);
//       }
//     };
//     fetchVideos();
//   }, [category]);

//   if (loading) {
//     return <div>Loading...</div>;
//   }

//   if (videos.length === 0) {
//     return <div>No videos available for this category.</div>;
//   }

//   return (
//     <div>
//       <h1>{category.toUpperCase()}</h1>
//       <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
//         {videos.map((video) => (
//           <div key={video._id}>
//             <video
//               src={`http://localhost:5001/uploads/${video.filename}`}
//               controls
//               style={{ width: '100%' }}
//             />
//             <p>{video.filename.replace('.mp4', '').toUpperCase()}</p>
//           </div>
//         ))}
//       </div>
//       <button onClick={onBack}>Back</button>
//     </div>
//   );
// }











// import { useEffect, useState } from 'react';

// interface Video {
//   _id: string;
//   filename: string;
//   category: string;
// }

// interface SignListProps {
//   category: string; // Selected category (e.g., alphabet, colors, fruits)
//   onSelectSign: (signId: string) => void; // Callback for navigating to the video
//   onBack: () => void; // Callback for navigating back
// }

// export default function SignList({ category, onSelectSign, onBack }: SignListProps) {
//   const [videos, setVideos] = useState<Video[]>([]);
//   const [loading, setLoading] = useState(true);

//   useEffect(() => {
//     const fetchVideos = async () => {
//       try {
//         const response = await fetch(`http://localhost:5001/api/videos/${category}`);
//         if (!response.ok) {
//           throw new Error('Failed to fetch videos');
//         }
//         const data = await response.json();
//         setVideos(data);
//       } catch (error) {
//         console.error('Error fetching videos:', error);
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchVideos();
//   }, [category]);

//   if (loading) {
//     return <div>Loading...</div>;
//   }

//   if (videos.length === 0) {
//     return (
//       <div>
//         <h1>No videos available for this category.</h1>
//         <button onClick={onBack}>Back</button>
//       </div>
//     );
//   }

//   return (
//     <div>
//       <h1>Signs for Category: {category.toUpperCase()}</h1>
//       <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
//         {videos.map((video) => (
//           <div
//             key={video._id}
//             style={{ border: '1px solid #ddd', padding: '10px', cursor: 'pointer' }}
//             onClick={() => onSelectSign(video._id)}
//           >
//             <h3>{video.filename.replace('.mp4', '').toUpperCase()}</h3>
//           </div>
//         ))}
//       </div>
//       <button onClick={onBack}>Back</button>
//     </div>
//   );
// }





// -------------------------------------------------------------------------------------------------------------------------------
// WORKINGG
import { useEffect, useState } from 'react';

interface Video {
  _id: string;
  filename: string;
  category: string;
}

interface SignListProps {
  category: string;
  onSelectSign: (videoUrl: string) => void;
  onBack: () => void;
}

export default function SignList({ category, onSelectSign, onBack }: SignListProps) {
  const [videos, setVideos] = useState<Video[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchVideos = async () => {
      try {
        const response = await fetch(`http://localhost:5001/api/videos/${category}`);
        const data = await response.json();
        setVideos(data);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching videos:', error);
        setLoading(false);
      }
    };
    fetchVideos();
  }, [category]);

  if (loading) return <div>Loading...</div>;

  return (
    <div>
      <header style={{ textAlign: 'center', marginBottom: '20px' }}>
        <h1 style={{ fontSize: '28px', fontWeight: 'bold', color: '#444' }}>
          {category.toUpperCase()}
        </h1>
      </header>
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(2, 1fr)',
          gap: '20px',
          padding: '10px',
        }}
      >
        {videos.map((video) => (
          <div
            key={video._id}
            // onClick={() => onSelectSign(`http://localhost:5001/api/stream/${video.filename}`)}
            onClick={() => {
              const videoUrl = `http://localhost:5001/api/stream/${video.filename}`;
              console.log('Generated video URL:', videoUrl); // Add this log
              onSelectSign(video.filename);
            }}
            style={{
              backgroundColor: '#F4A460',
              padding: '20px',
              borderRadius: '10px',
              cursor: 'pointer',
              textAlign: 'center',
              boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
            }}
          >
            <span style={{ fontSize: '20px', fontWeight: 'bold', color: '#FFF' }}>
              {video.filename.replace('.mp4', '').toUpperCase()}
            </span>
          </div>
        ))}
      </div>
      <button
            onClick={onBack}
            style={{
              padding: '10px 20px',
              backgroundColor: '#ddd',
              border: 'none',
              borderRadius: '5px',
              cursor: 'pointer'
            }}
          >
            Back
      </button>
    </div>
  );
}
// -------------------------------------------------------------------------------------------------------------------------------

