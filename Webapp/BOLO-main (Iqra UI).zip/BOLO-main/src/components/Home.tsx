interface HomeProps {
  onNavigate: () => void;
}

export default function Home({ onNavigate }: HomeProps) {
  return (
    <div style={{ textAlign: 'center' }}>
      {/* <h1 style={{ fontSize: '20px', marginBottom: '20px' }}>Hello From</h1> */}
      <img
        src={'../blogo.png'}
        alt="BOLO Logo"
        className="w-48 mx-auto mb-8"
      />
      <div
        onClick={onNavigate}
        style={{
          backgroundColor: '#F4A460',
          padding: '40px',
          borderRadius: '10px',
          marginBottom: '20px',
          cursor: 'pointer'
        }}
      >
        <span style={{ color: 'white', fontSize: '24px' }}>Categories</span>
      </div>
      <div
        style={{
          backgroundColor: '#F4A460',
          padding: '40px',
          borderRadius: '10px',
          cursor: 'pointer'
        }}
      >
        <span style={{ color: 'white', fontSize: '24px' }}>Practice</span>
      </div>
    </div>
  );
}




// import { useState } from 'react';
// import boloLogo from '/public/blogo.png';

// interface HomeProps {
//   onNavigate: () => void;
//   onPractice: () => void;
// }

// export default function Home({ onNavigate, onPractice }: HomeProps) {
//   const [isHoveringCategories, setIsHoveringCategories] = useState(false);
//   const [isHoveringPractice, setIsHoveringPractice] = useState(false);

//   return (
//     <div className="flex flex-col items-center justify-center min-h-[80vh]">
//       <div className="text-center w-full max-w-md">
//         <h1 className="text-2xl font-semibold text-gray-800 mb-4">Welcome Back To</h1>
//         <div className="mb-12">
//           <img
//             src={boloLogo}
//             alt="BOLO Logo"
//             className="w-48 mx-auto"
//           />
//         </div>
        
//         <div 
//           onClick={onNavigate}
//           onMouseEnter={() => setIsHoveringCategories(true)}
//           onMouseLeave={() => setIsHoveringCategories(false)}
//           className={`
//             bg-[#F4A460] p-10 rounded-lg mb-6 cursor-pointer
//             transform transition-all duration-200 shadow-md
//             ${isHoveringCategories ? 'scale-105 shadow-lg' : ''}
//           `}
//         >
//           <span className="text-white text-2xl font-semibold tracking-wide">
//             Categories
//           </span>
//         </div>

//         <div 
//           onClick={onPractice}
//           onMouseEnter={() => setIsHoveringPractice(true)}
//           onMouseLeave={() => setIsHoveringPractice(false)}
//           className={`
//             bg-[#F4A460] p-10 rounded-lg cursor-pointer
//             transform transition-all duration-200 shadow-md
//             ${isHoveringPractice ? 'scale-105 shadow-lg' : ''}
//           `}
//         >
//           <span className="text-white text-2xl font-semibold tracking-wide">
//             Practice
//           </span>
//         </div>
//       </div>
//     </div>
//   );
// }