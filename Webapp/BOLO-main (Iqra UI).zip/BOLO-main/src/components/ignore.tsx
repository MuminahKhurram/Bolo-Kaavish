import React, { useState, useRef } from 'react';
import axios from 'axios';
import Webcam from 'react-webcam';

interface PracticeSessionProps {
  sign: string;
  onBack: () => void;
}

const sequenceLength = 80; // Number of frames to capture

export default function PracticeSession({
  sign,
  onBack,
}: PracticeSessionProps) {
  const webcamRef = useRef<Webcam>(null);  // Use webcamRef for react-webcam
  const [prediction, setPrediction] = useState<string | null>(null);
  const [confidence, setConfidence] = useState<number | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const captureFrame = (capturedFrames: Blob[]) => {
    const video = webcamRef.current?.getScreenshot();  // Get screenshot from react-webcam

    if (video) {
      // Convert the base64 image to a Blob
      fetch(video)
        .then((res) => res.blob())
        .then((blob) => {
          capturedFrames.push(blob);
        });
    }
  };

  const fetchPrediction = async (frames: Blob[]) => {
    try {
      const formData = new FormData();
      frames.forEach((frame, index) => formData.append(`frame${index}`, frame));
      console.log('Sending request to backend with frames:', frames.length);

      const response = await axios.post('http://localhost:5000/predict', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      console.log('Backend response:', response.data);  
      setPrediction(response.data.prediction);
      setConfidence(response.data.confidence);
      setError(null);
    } catch (err) {
      console.error('Failed to get prediction:', err);
      setError('Failed to get prediction. Please try again.');
    }
  };

  const startRecording = () => {
    setIsRecording(true);
    setPrediction(null);
    setConfidence(null);
    setError(null);

    const capturedFrames: Blob[] = [];
    const startTime = Date.now();

    const captureInterval = setInterval(() => {
      if (capturedFrames.length >= sequenceLength) {
        clearInterval(captureInterval);
        setIsRecording(false);
        fetchPrediction(capturedFrames);
      } else {
        captureFrame(capturedFrames);
      }
    }, 100);
  };

  return (
    <div className="text-center">
      <h1 className="text-2xl font-bold mb-5">Practice: {sign.toUpperCase()}</h1>

      <Webcam
        ref={webcamRef}
        width="640"
        height="480"
        screenshotFormat="image/jpeg"
        videoConstraints={{
          facingMode: "user",  // Optional: use user-facing camera (front camera)
        }}
        className="border-2 border-black mb-5"
      />

      <button
        onClick={startRecording}
        disabled={isRecording}
        className={`px-4 py-2 text-white font-bold rounded-lg ${
          isRecording ? 'bg-gray-400' : 'bg-blue-500 hover:bg-blue-600'
        }`}
      >
        {isRecording ? 'Recording...' : 'Start Recording'}
      </button>

      {prediction && (
        <div className="mt-5">
          <h2 className="text-xl font-bold">Prediction: {prediction}</h2>
          <p>Confidence: {(confidence! * 100).toFixed(2)}%</p>
        </div>
      )}

      {error && (
        <div className="text-red-500 mt-5">
          <p>{error}</p>
        </div>
      )}

      <div className="mt-5 flex gap-4 justify-center">
        <button
          onClick={onBack}
          className="px-4 py-2 bg-gray-300 rounded-lg hover:bg-gray-400"
        >
          Back
        </button>
      </div>
    </div>
  );
}
