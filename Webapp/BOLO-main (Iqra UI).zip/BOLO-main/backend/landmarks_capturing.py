import cv2
import mediapipe as mp
import os
import csv

# Initialize MediaPipe Holistic model
mp_holistic = mp.solutions.holistic
holistic = mp_holistic.Holistic(static_image_mode=False, model_complexity=1, min_detection_confidence=0.5, min_tracking_confidence=0.5)

# Define paths
input_folder = "full_augmented"
output_folder = "full_augmented"

# Create the output folder if it doesn't exist
os.makedirs(output_folder, exist_ok=True)

# Target frames per second (FPS) for processing
target_fps = 5

def process_video(video_path, output_csv_path):
    # Open the video file
    cap = cv2.VideoCapture(video_path)
    original_fps = cap.get(cv2.CAP_PROP_FPS)
    frame_skip = int(original_fps / target_fps)  # Calculate frame skip to achieve 5 FPS
    frame_count = 0
    
    # Prepare to save landmarks data
    with open(output_csv_path, mode='w', newline='') as csv_file:
        csv_writer = csv.writer(csv_file)
        
        # Write headers for the CSV file (x, y, z coordinates for each landmark)
        headers = ["frame"]
        for part in ["pose", "left_hand", "right_hand", "face"]:
            for i in range(33 if part == "pose" else 21 if "hand" in part else 468):
                headers.extend([f"{part}_{i}_x", f"{part}_{i}_y", f"{part}_{i}_z"])
        csv_writer.writerow(headers)
        
        # Process each frame in the video, skipping to achieve 5 FPS
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break
            
            # Only process every nth frame to achieve the target FPS
            if frame_count % frame_skip != 0:
                frame_count += 1
                continue

            # Convert the frame to RGB (required by MediaPipe)
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            
            # Process the frame with MediaPipe Holistic
            results = holistic.process(frame_rgb)
            
            # Skip frames without hand landmarks
            if not (results.left_hand_landmarks or results.right_hand_landmarks):
                frame_count += 1
                continue
            
            # Collect landmarks
            row = [frame_count]
            
            # Extract pose landmarks
            if results.pose_landmarks:
                row.extend([coord for lm in results.pose_landmarks.landmark for coord in (lm.x, lm.y, lm.z)])
            else:
                row.extend([None] * (33 * 3))
            
            # Extract left hand landmarks
            if results.left_hand_landmarks:
                row.extend([coord for lm in results.left_hand_landmarks.landmark for coord in (lm.x, lm.y, lm.z)])
            else:
                row.extend([None] * (21 * 3))
            
            # Extract right hand landmarks
            if results.right_hand_landmarks:
                row.extend([coord for lm in results.right_hand_landmarks.landmark for coord in (lm.x, lm.y, lm.z)])
            else:
                row.extend([None] * (21 * 3))
            
            # Extract face landmarks
            if results.face_landmarks:
                row.extend([coord for lm in results.face_landmarks.landmark for coord in (lm.x, lm.y, lm.z)])
            else:
                row.extend([None] * (468 * 3))
            
            # Write the row to the CSV
            csv_writer.writerow(row)
            
            # Increment the frame count
            frame_count += 1
            
    # Release the video capture object
    cap.release()

# Loop over all videos in the folder
for video_file in os.listdir(input_folder):
    if video_file.endswith(".mp4") or video_file.endswith(".avi"):
        video_path = os.path.join(input_folder, video_file)
        output_csv_path = os.path.join(output_folder, f"{os.path.splitext(video_file)[0]}_landmarks.csv")
        
        print(f"Processing {video_file}...")
        process_video(video_path, output_csv_path)
        print(f"Landmarks saved to {output_csv_path}")

# Release the holistic model
holistic.close()
