import os
import csv
import cv2
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, LabelEncoder
from torch.utils.data import DataLoader, Dataset
import torch
import torch.nn as nn
import torch.nn.utils.rnn as rnn_utils
import mediapipe as mp

# Target FPS
target_fps = 5

# Initialize Mediapipe Holistic
mp_holistic = mp.solutions.holistic
holistic = mp_holistic.Holistic(static_image_mode=False, model_complexity=1, min_detection_confidence=0.5, min_tracking_confidence=0.5)

# Data preparation functions
def prepare_data(feature_files, sequence_length=10):
    all_columns = set()
    data = []

    for file in feature_files:
        # Read file into DataFrame
        df = pd.read_csv(file)
        all_columns.update(df.columns)

        # Ensure consistent columns across files
        df = df.reindex(columns=sorted(list(all_columns)), fill_value=0)
        values = df.drop(columns=["frame"], errors="ignore").values

        # Pad or truncate sequences
        if len(values) < sequence_length:
            padded_sequence = np.zeros((sequence_length, values.shape[1]))
            padded_sequence[:len(values)] = values
            values = padded_sequence
        else:
            values = values[:sequence_length]

        data.append(values)

    return np.array(data)

def normalize_sequences(data, scaler=None):
    reshaped_data = data.reshape(-1, data.shape[2])
    if scaler is None:
        scaler = StandardScaler()
        reshaped_data = scaler.fit_transform(reshaped_data)
    else:
        reshaped_data = scaler.transform(reshaped_data)

    data_normalized = reshaped_data.reshape(data.shape)
    data_normalized[np.isnan(data_normalized)] = 0
    data_normalized[np.isinf(data_normalized)] = 0
    return data_normalized, scaler

# Dataset class with masking
class FeatureDatasetWithMasking(Dataset):
    def __init__(self, data, sequence_length):
        self.data = data
        self.sequence_length = sequence_length

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        sequence = self.data[idx]

        # Create mask for valid frames
        sequence_length = min(len(sequence), self.sequence_length)
        mask = torch.zeros(self.sequence_length, dtype=torch.bool)
        mask[:sequence_length] = 1

        # Pad the sequence if necessary
        padded_sequence = torch.zeros((self.sequence_length, sequence.shape[1]), dtype=torch.float32)
        padded_sequence[:sequence_length] = torch.tensor(sequence[:sequence_length], dtype=torch.float32)

        return padded_sequence, mask

# RNN model with masking
class RNNClassifierWithMasking(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers, num_classes, bidirectional=True):
        super(RNNClassifierWithMasking, self).__init__()
        self.rnn = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True, bidirectional=bidirectional, dropout=0.2)
        self.fc = nn.Linear(hidden_size * (2 if bidirectional else 1), num_classes)

    def forward(self, x, mask):
        packed_x = rnn_utils.pack_padded_sequence(x, mask.sum(dim=1).cpu(), batch_first=True, enforce_sorted=False)
        packed_output, (hn, _) = self.rnn(packed_x)
        output, _ = rnn_utils.pad_packed_sequence(packed_output, batch_first=True)

        last_valid_index = (mask.sum(dim=1) - 1).to(torch.int64)
        last_hidden_state = output[torch.arange(len(last_valid_index)), last_valid_index]

        out = self.fc(last_hidden_state)
        return out

def real_time_gesture_recognition(model_path, scaler_path, label_classes_path, sequence_length=10):
    """Pipeline to record, process, and evaluate gestures in real time."""
    cap = cv2.VideoCapture(0)  # Use webcam as the video source
    original_fps = cap.get(cv2.CAP_PROP_FPS)
    frame_skip = max(1, int(original_fps / target_fps))
    frame_count = 0
    recording = False

    # Load the saved model
    label_encoder = LabelEncoder()
    label_encoder.classes_ = np.load(label_classes_path, allow_pickle=True)
    num_classes = len(label_encoder.classes_)

    scaler_mean = np.load(f"{scaler_path}_mean_working.npy")
    scaler_scale = np.load(f"{scaler_path}_scale_working.npy")
    scaler = StandardScaler()
    scaler.mean_ = scaler_mean
    scaler.scale_ = scaler_scale

    input_size = 1629
    hidden_size = 128  # Ensure consistency with training
    num_layers = 2
    # num_classes = len(np.load(label_classes_path, allow_pickle=True))
    model = RNNClassifierWithMasking(input_size, hidden_size, num_layers, num_classes, bidirectional=True)
    model.load_state_dict(torch.load(model_path))
    model.eval()

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        # Display the live feed
        cv2.putText(frame, "Press 'R' to record, 'Q' to predict, 'ESC' to quit.", (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 0, 0), 2)
        cv2.imshow('Gesture Recognition', frame)

        # Check for key presses
        key = cv2.waitKey(1) & 0xFF
        if key == 27:  # ESC to quit
            print("Exiting...")
            break
        elif key == ord('r'):  # Start recording
            print("Recording started...")
            recording = True
            frame_count = 0
            recorded_data = []
        elif key == ord('q') and recording:  # Stop recording and predict
            print("Recording stopped. Predicting gesture...")
            recording = False
            # Save to temporary CSV
            temp_csv = "temp_gesture.csv"
            with open(temp_csv, mode='w', newline='') as csv_file:
                csv_writer = csv.writer(csv_file)
                headers = ["frame"]
                for part in ["pose", "left_hand", "right_hand", "face"]:
                    for i in range(33 if part == "pose" else 21 if "hand" in part else 468):
                        headers.extend([f"{part}_{i}_x", f"{part}_{i}_y", f"{part}_{i}_z"])
                csv_writer.writerow(headers)
                csv_writer.writerows(recorded_data)
                

            # Prepare data and predict
            data = prepare_data([temp_csv], sequence_length)
            data_normalized, _ = normalize_sequences(data, scaler)
            test_dataset = FeatureDatasetWithMasking(data_normalized, sequence_length)
            test_loader = DataLoader(test_dataset, batch_size=1, shuffle=False)

            all_preds = []
            all_probs = []
            with torch.no_grad():
                for sequences, masks in test_loader:
                    sequences, masks = sequences.float(), masks.float()
                    outputs = model(sequences, masks)
                    probs = torch.softmax(outputs, dim=1)  # Apply softmax to get probabilities
                    preds = torch.argmax(probs, dim=1)  # Get the class with the highest probability
                    all_preds.extend(preds.cpu().numpy())
                    all_probs.extend(probs.cpu().numpy())  # Save all probabilities for confidence

            # Decode predictions
            predicted_label = label_encoder.inverse_transform(all_preds)
            prediction_confidence = all_probs[0][all_preds[0]]  # Get the confidence for the predicted class

            # Print prediction and confidence
            print(f"Predicted Gesture: {predicted_label[0]} with confidence: {prediction_confidence:.2f}")
                
            cv2.putText(frame, f"Prediction: {predicted_label[0]}", (10, 60),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
            cv2.imshow('Gesture Recognition', frame)
            

        # Record data if recording
        if recording:
            if frame_count % frame_skip != 0:
                frame_count += 1
                continue
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = holistic.process(frame_rgb)
            row = [frame_count]
            if not (results.left_hand_landmarks or results.right_hand_landmarks):
                frame_count += 1
                continue
            if results.pose_landmarks:
                row.extend([coord for lm in results.pose_landmarks.landmark for coord in (lm.x, lm.y, lm.z)])
            else:
                row.extend([None] * (33 * 3))
            if results.left_hand_landmarks:
                row.extend([coord for lm in results.left_hand_landmarks.landmark for coord in (lm.x, lm.y, lm.z)])
            else:
                row.extend([None] * (21 * 3))
            if results.right_hand_landmarks:
                row.extend([coord for lm in results.right_hand_landmarks.landmark for coord in (lm.x, lm.y, lm.z)])
            else:
                row.extend([None] * (21 * 3))
            if results.face_landmarks:
                row.extend([coord for lm in results.face_landmarks.landmark for coord in (lm.x, lm.y, lm.z)])
            else:
                row.extend([None] * (468 * 3))
            recorded_data.append(row)
            frame_count += 1

    cap.release()
    cv2.destroyAllWindows()


# Example usage
real_time_gesture_recognition(
    model_path="rnn_classifier_with_masking_working.pth",  # Path to the saved model
    scaler_path="scaler",  # Prefix for saved scaler files
    label_classes_path="label_classes_working.npy",  # Path to saved label classes
    sequence_length=10
)
