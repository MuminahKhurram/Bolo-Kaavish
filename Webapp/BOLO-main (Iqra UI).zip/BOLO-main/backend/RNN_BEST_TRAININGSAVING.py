import os
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from torch.utils.data import Dataset, DataLoader
import torch
import torch.nn as nn
import torch.optim as optim
import re

labels =[]
# Preprocess data and extract labels
def prepare_data(feature_files, sequence_length=10):
    all_columns = set()
    data = []
    labels = []

    for file in feature_files:
        # Read file into DataFrame
        df = pd.read_csv(file)
        all_columns.update(df.columns)

        # Extract label from the filename
        filename = os.path.basename(file)  # Get the file name
        # Extract the label before an underscore (_) or the word "augmented"
        label = re.split(r"_|augmented", filename)[0]
        labels.append(label)

        # Prepare the feature data
        df = df.reindex(columns=sorted(list(all_columns)), fill_value=0)  # Ensure consistent columns
        values = df.drop(columns=["frame"], errors="ignore").values
        if len(values) < sequence_length:
            padded_sequence = np.zeros((sequence_length, values.shape[1]))
            padded_sequence[:len(values)] = values
            values = padded_sequence
        else:
            values = values[:sequence_length]
        data.append(values)

    return np.array(data), labels, sorted(list(all_columns))

# Load and normalize data
input_folder = "full_augmented_landmarks"
feature_files = [os.path.join(input_folder, file) for file in os.listdir(input_folder) if file.endswith(".csv")]

# Call the function to get features and labels
data, labels, all_columns = prepare_data(feature_files, sequence_length=10)
# print("labels are:", labels)



scaler = StandardScaler()
data_reshaped = data.reshape(-1, data.shape[2])
data_normalized = scaler.fit_transform(data_reshaped)
data = data_normalized.reshape(data.shape)
data[np.isnan(data)] = 0
data[np.isinf(data)] = 0
# Save scaler during training
np.save("scaler_mean_working.npy", scaler.mean_)
np.save("scaler_scale_working.npy", scaler.scale_)






# from sklearn.model_selection import train_test_split
# from sklearn.neighbors import KNeighborsClassifier
# from sklearn.metrics import accuracy_score, classification_report

# # Split into training and testing sets
# X_train, X_test, y_train, y_test = train_test_split(extracted_features, labels, test_size=0.2, random_state=42)
# # Initialize and train the KNN classifier
# knn = KNeighborsClassifier(n_neighbors=3)  # Use k=5 neighbors (adjust as needed)
# knn.fit(X_train, y_train)
# # Make predictions
# y_pred = knn.predict(X_test)

# # Evaluate the classifier
# accuracy = accuracy_score(y_test, y_pred)
# print(f"Accuracy: {accuracy:.2f}")

# # Detailed classification report
# print("Classification Report:")
# print(classification_report(y_test, y_pred))

import torch.nn.utils.rnn as rnn_utils
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from torch.utils.data import DataLoader, Dataset

# Dataset with padding and masking
class FeatureDatasetWithMasking(Dataset):
    def __init__(self, data, labels, sequence_length):
        self.data = data
        self.labels = labels
        self.sequence_length = sequence_length

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        sequence = self.data[idx]
        label = self.labels[idx]
        
        # Mask for valid frames
        sequence_length = min(len(sequence), self.sequence_length)
        mask = torch.zeros(self.sequence_length, dtype=torch.bool)
        mask[:sequence_length] = 1  # Mark valid frames
        
        # Pad the sequence if necessary
        padded_sequence = torch.zeros((self.sequence_length, sequence.shape[1]), dtype=torch.float32)
        padded_sequence[:sequence_length] = torch.tensor(sequence[:sequence_length], dtype=torch.float32)

        return padded_sequence, mask, label


# New forward function with masking
class RNNClassifierWithMasking(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers, num_classes, bidirectional=True):
        super(RNNClassifierWithMasking, self).__init__()
        self.rnn = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True, bidirectional=bidirectional, dropout=0.2)
        self.fc = nn.Linear(hidden_size * (2 if bidirectional else 1), num_classes)

    def forward(self, x, mask):
        # Use masking to ignore padded frames
        packed_x = rnn_utils.pack_padded_sequence(x, mask.sum(dim=1).cpu(), batch_first=True, enforce_sorted=False)
        packed_output, (hn, _) = self.rnn(packed_x)
        output, _ = rnn_utils.pad_packed_sequence(packed_output, batch_first=True)
        
        # Use the last valid frame's hidden state
        last_valid_index = (mask.sum(dim=1) - 1).to(torch.int64)  # Ensure indices are of type int64
        last_hidden_state = output[torch.arange(len(last_valid_index)), last_valid_index]
        
        out = self.fc(last_hidden_state)  # Map to class scores
        return out



def normalize_sequences(data, target_length):
    resampled_data = []
    for sequence in data:
        resampled_sequence = []
        for feature_index in range(sequence.shape[1]):  # Iterate over features
            resampled_feature = np.interp(
                np.linspace(0, len(sequence) - 1, target_length),
                np.arange(len(sequence)),
                sequence[:, feature_index]
            )
            resampled_sequence.append(resampled_feature)
        resampled_data.append(np.array(resampled_sequence).T)  # Transpose back to original format
    return np.array(resampled_data)



# Normalize data for uniform sequence length
target_length = 10
data_normalized = normalize_sequences(data, target_length)

# Encode labels
label_encoder = LabelEncoder()
encoded_labels = label_encoder.fit_transform(labels)
np.save("label_classes_working.npy", label_encoder.classes_)

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(data_normalized, encoded_labels, test_size=0.2, random_state=42)

# Create datasets and dataloaders
sequence_length = target_length
train_dataset = FeatureDatasetWithMasking(X_train, y_train, sequence_length)
test_dataset = FeatureDatasetWithMasking(X_test, y_test, sequence_length)

train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)
test_loader = DataLoader(test_dataset, batch_size=32, shuffle=False)

# Initialize model
input_size = X_train.shape[2]
hidden_size = 128
num_layers = 2
num_classes = len(label_encoder.classes_)
model = RNNClassifierWithMasking(input_size, hidden_size, num_layers, num_classes, bidirectional=True)

# Training
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.0001)
num_epochs = 100

for epoch in range(num_epochs):
    model.train()
    epoch_loss = 0
    for sequences, masks, labels in train_loader:
        sequences, masks, labels = sequences.float(), masks.float(), labels.long()
        
        optimizer.zero_grad()
        outputs = model(sequences, masks)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()
        
        epoch_loss += loss.item()
    print(f"Epoch [{epoch+1}/{num_epochs}], Loss: {epoch_loss:.4f}")

# Save the model
torch.save(model.state_dict(), "rnn_classifier_with_masking_working.pth")
print("Classifier model saved to 'rnn_classifier_with_masking_working.pth'")

# Evaluation
model.eval()
all_preds = []
all_labels = []

with torch.no_grad():
    for sequences, masks, labels in test_loader:
        sequences, masks, labels = sequences.float(), masks.float(), labels.long()
        outputs = model(sequences, masks)
        preds = torch.argmax(outputs, dim=1)
        
        all_preds.extend(preds.cpu().numpy())
        all_labels.extend(labels.cpu().numpy())

# Decode predictions and labels
y_pred_labels = label_encoder.inverse_transform(all_preds)
y_test_labels = label_encoder.inverse_transform(all_labels)

# Classification report
from sklearn.metrics import classification_report
print(classification_report(y_test_labels, y_pred_labels))
