import os
import csv
import cv2
import numpy as np
from flask import Flask, request, jsonify
import torch
from torch.utils.data import DataLoader
from sklearn.preprocessing import StandardScaler, LabelEncoder
from detect_sign import prepare_data, normalize_sequences, FeatureDatasetWithMasking, RNNClassifierWithMasking
import mediapipe as mp
from flask_cors import CORS
import tempfile

app = Flask(__name__)

# This will allow all origins to access your Flask API
CORS(app, origins=["http://localhost:5173"])

mp_holistic = mp.solutions.holistic
holistic = mp_holistic.Holistic(static_image_mode=False, model_complexity=1, min_detection_confidence=0.5, min_tracking_confidence=0.5)

# Load the model and scaler when the app starts
label_encoder = LabelEncoder()
label_encoder.classes_ = np.load("label_classes_working.npy", allow_pickle=True)
scaler_mean = np.load("scaler_mean_working.npy")
scaler_scale = np.load("scaler_scale_working.npy")
scaler = StandardScaler()
scaler.mean_ = scaler_mean
scaler.scale_ = scaler_scale

model = RNNClassifierWithMasking(input_size=1629, hidden_size=128, num_layers=2, num_classes=len(label_encoder.classes_), bidirectional=True)
model.load_state_dict(torch.load("rnn_classifier_with_masking_working.pth"))
model.eval()

frame_buffer = []
sequence_length = 10  # Define the number of frames in a sequence
frame_count = 0  # Keeps track of the frame count for every frame received
frame_skip = 5  # Only process every 5th frame if a hand is detected

@app.route('/')
def index():
    return "Welcome to the Gesture Recognition API!"

@app.route('/predict', methods=['POST'])
def predict():
    """API endpoint for real-time gesture prediction."""
    frames = []

    # Check if files are present in the request
    if not request.files:
        return jsonify({'error': 'No frame files provided'}), 400
    
    # Collect all frames from the request
    for key in request.files:
        frame = request.files[key].read()  # Get each frame image as bytes
        nparr = np.frombuffer(frame, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        if img is None:
            return jsonify({'error': 'Invalid image file'}), 400
        frames.append(img)  # Add the frame to the list

    if not frames:
        return jsonify({'error': 'No valid frames received'}), 400

    # Now, process the sequence of frames
    predicted_label, prediction_confidence = real_time_gesture_recognition(model, scaler, label_encoder, frames)

    return jsonify({
        'prediction': predicted_label,
        'confidence': prediction_confidence
    })

def real_time_gesture_recognition(model, scaler, label_encoder, frames):
    """Process multiple frames, normalize data, and predict gesture from sequence."""
    global frame_count  # We are modifying the global frame count

    # Initialize frame buffer for the sequence
    frame_buffer = []

    for frame in frames:  # Process each frame in the sequence
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = holistic.process(frame_rgb)
        
        row = [frame_count]

        # Extract landmarks (pose, hands, and face) for each frame
        
        if results.pose_landmarks:
            row.extend([coord for lm in results.pose_landmarks.landmark for coord in (lm.x, lm.y, lm.z)])
        else:
            row.extend([None] * (33 * 3))  # Fill with None if pose landmarks are missing

        if results.left_hand_landmarks:
            row.extend([coord for lm in results.left_hand_landmarks.landmark for coord in (lm.x, lm.y, lm.z)])
        else:
            row.extend([None] * (21 * 3))  # Fill with None if left hand landmarks are missing

        if results.right_hand_landmarks:
            row.extend([coord for lm in results.right_hand_landmarks.landmark for coord in (lm.x, lm.y, lm.z)])
        else:
            row.extend([None] * (21 * 3))  # Fill with None if right hand landmarks are missing

        if results.face_landmarks:
            row.extend([coord for lm in results.face_landmarks.landmark for coord in (lm.x, lm.y, lm.z)])
        else:
            row.extend([None] * (468 * 3))  # Fill with None if face landmarks are missing

        # Add the row to the frame buffer
        frame_buffer.append(row)
        frame_count += 1

    print(f"Frame buffer length: {len(frame_buffer)}")

    # If we have enough frames in the sequence, process them for prediction
    if len(frame_buffer) >= sequence_length:
        return process_sequence_and_predict(frame_buffer, model, scaler, label_encoder)
    
    return None, None  # Not enough frames yet to process

def process_sequence_and_predict(frame_buffer, model, scaler, label_encoder):
    """Normalize data, prepare for input to model, and make prediction."""
    # Save the buffered frames temporarily to a CSV file
    with tempfile.NamedTemporaryFile(delete=False, mode='w', newline='') as temp_file:
        writer = csv.writer(temp_file)
        
        # Write headers for CSV
        headers = ["frame"]
        for part in ["pose", "left_hand", "right_hand", "face"]:
            for i in range(33 if part == "pose" else 21 if "hand" in part else 468):
                headers.extend([f"{part}_{i}_x", f"{part}_{i}_y", f"{part}_{i}_z"])
        writer.writerow(headers)
        
        # Write frames data
        writer.writerows(frame_buffer)
        temp_file.close()

        # Prepare the data and make a prediction
        data = prepare_data([temp_file.name], sequence_length=sequence_length)
    
    # Normalize the sequence data
    data_normalized, _ = normalize_sequences(data, scaler)
    
    # Create dataset and dataloader
    test_dataset = FeatureDatasetWithMasking(data_normalized, sequence_length=sequence_length)
    test_loader = DataLoader(test_dataset, batch_size=1, shuffle=False)

    # Make prediction using the model
    with torch.no_grad():
        for sequences, masks in test_loader:
            sequences, masks = sequences.float(), masks.float()
            outputs = model(sequences, masks)
            probs = torch.softmax(outputs, dim=1)  # Apply softmax to get probabilities
            preds = torch.argmax(probs, dim=1)  # Get the class with the highest probability
            predicted_label = label_encoder.inverse_transform(preds.cpu().numpy())
            prediction_confidence = probs[0][preds[0]].item()

    # Return the predicted label and confidence
    return predicted_label[0], prediction_confidence

if __name__ == "__main__":
    app.run(debug=True, host='0.0.0.0', port=5000)
