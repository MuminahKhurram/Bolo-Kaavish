// import express from 'express';
// import cors from 'cors';
// import multer from 'multer';
// import { PythonShell } from 'python-shell';
// import { fileURLToPath } from 'url';
// import { dirname, join } from 'path';
// import fs from 'fs/promises';

// const __filename = fileURLToPath(import.meta.url);
// const __dirname = dirname(__filename);

// // Configure multer for video upload
// const storage = multer.diskStorage({
//   destination: function (req, file, cb) {
//     cb(null, 'uploads/');
//   },
//   filename: function (req, file, cb) {
//     cb(null, Date.now() + '-' + file.originalname);
//   }
// });

// const upload = multer({ storage: storage });

// const app = express();

// app.use(cors());
// app.use(express.json());

// // Ensure uploads directory exists
// await fs.mkdir('uploads', { recursive: true }).catch(console.error);

// app.post('/api/detect-sign', upload.single('video'), async (req, res) => {
//   try {
//     if (!req.file) {
//       return res.status(400).json({ error: 'No video file provided' });
//     }

//     const options = {
//       mode: 'text',
//       pythonPath: process.env.PYTHON_PATH || 'python3',
//       pythonOptions: ['-u'],
//       scriptPath: join(__dirname, 'python'),
//       args: [req.file.path]
//     };

//     try {
//       const results = await PythonShell.run('detect_sign.py', options);
//       const prediction = JSON.parse(results[0]);
      
//       // Cleanup uploaded file
//       await fs.unlink(req.file.path).catch(console.error);
      
//       res.json(prediction);
//     } catch (err) {
//       console.error('Python script error:', err);
//       // Cleanup uploaded file even on error
//       await fs.unlink(req.file.path).catch(console.error);
      
//       res.status(500).json({ 
//         error: 'Error processing video',
//         details: process.env.NODE_ENV === 'development' ? err.message : undefined
//       });
//     }
//   } catch (error) {
//     console.error('Server error:', error);
//     // Cleanup uploaded file if it exists
//     if (req.file) {
//       await fs.unlink(req.file.path).catch(console.error);
//     }
    
//     res.status(500).json({ 
//       error: 'Internal server error',
//       details: process.env.NODE_ENV === 'development' ? error.message : undefined
//     });
//   }
// });

// const PORT = process.env.PORT || 3001;
// app.listen(PORT, () => {
//   console.log(`Server running on port ${PORT}`);
// });
















// -------------------------------------------------------------------------------------------------------------------------------
// WORKINGG
import express from 'express';
import cors from 'cors';
import multer from 'multer';
import { PythonShell } from 'python-shell';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import fs from 'fs/promises';
import { MongoClient, GridFSBucket } from 'mongodb';

// Set up paths
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// MongoDB connection
const mongoURI = 'mongodb+srv://mk07521:L0kuOy5N0oqi94qS@videos.2fld2.mongodb.net/?retryWrites=true&w=majority&appName=Videos';
const client = new MongoClient(mongoURI);
const database = client.db('App_Videos');
const collection = database.collection('fs.files');

// Multer configuration for video uploads
const storage = multer.diskStorage({
  destination: async function (req, file, cb) {
    const uploadDir = join(__dirname, 'uploads');
    await fs.mkdir(uploadDir, { recursive: true });
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '-' + file.originalname);
  }
});

const upload = multer({ storage });

// Initialize Express app
const app = express();
app.use(cors());
app.use(express.json());

// API: Fetch videos by category (MongoDB)
app.get('/api/videos/:category', async (req, res) => {
  const { category } = req.params;
  try {
    await client.connect();
    const videos = await collection.find({ category }).toArray();
    res.json(videos);
  } catch (error) {
    console.error('Error fetching videos:', error);
    res.status(500).send('Internal Server Error');
  }
});

// app.get('/api/stream/:filename', async (req, res) => {
//   const { filename } = req.params;

//   try {
//     await client.connect();
//     const db = client.db('App_Videos');
//     const bucket = new GridFSBucket(db);

//     console.log(`Looking for file: ${filename}`);

//     // Case-insensitive filename match
//     const fileExists = await db.collection('fs.files').findOne({
//       filename: { $regex: new RegExp(`^${filename}$`, 'i') }, // Case-insensitive regex
//     });

//     if (!fileExists) {
//       console.error(`File not found: ${filename}`);
//       return res.status(404).send('File not found');
//     }

//     console.log(`File found: ${fileExists.filename}`);

//     // Stream the video file
//     const stream = bucket.openDownloadStream(fileExists._id);

//     // Set headers to indicate video content
//     res.set({
//       'Content-Type': 'video/mp4',
//       'Content-Disposition': `inline; filename="${fileExists.filename}"`,
//     });

//     // Pipe the stream to the response
//     stream.pipe(res);
//   } catch (error) {
//     console.error('Error streaming video:', error);
//     res.status(500).send('Error streaming video');
//   }
// });

app.get('/api/stream/:filename', async (req, res) => {
  const { filename } = req.params;

  console.log(`Incoming request for video: ${filename}`); // Log every incoming request

  try {
    await client.connect();
    const db = client.db('App_Videos');
    const bucket = new GridFSBucket(db);

    // Check if the file exists
    const fileExists = await db.collection('fs.files').findOne({ filename });
    if (!fileExists) {
      console.error(`File not found: ${filename}`);
      return res.status(404).send('File not found');
    }

    console.log(`File found: ${fileExists.filename}`); // Log if the file is found

    // Stream the video
    const stream = bucket.openDownloadStream(fileExists._id);

    res.set({
      'Content-Type': 'video/mp4',
      'Content-Disposition': `inline; filename="${fileExists.filename}"`,
    });

    stream.pipe(res);
  } catch (error) {
    console.error('Error streaming video:', error);
    res.status(500).send('Error streaming video');
  }
});










// API: Video upload and Python processing
app.post('/api/detect-sign', upload.single('video'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No video file provided' });
    }

    const options = {
      mode: 'text',
      pythonPath: process.env.PYTHON_PATH || 'python3',
      pythonOptions: ['-u'],
      scriptPath: join(__dirname, 'python'),
      args: [req.file.path]
    };

    try {
      const results = await PythonShell.run('detect_sign.py', options);
      const prediction = JSON.parse(results[0]);
      
      // Cleanup uploaded file
      await fs.unlink(req.file.path).catch(console.error);
      
      res.json(prediction);
    } catch (err) {
      console.error('Python script error:', err);
      // Cleanup uploaded file even on error
      await fs.unlink(req.file.path).catch(console.error);
      
      res.status(500).json({ 
        error: 'Error processing video',
        details: process.env.NODE_ENV === 'development' ? err.message : undefined
      });
    }
  } catch (error) {
    console.error('Server error:', error);
    // Cleanup uploaded file if it exists
    if (req.file) {
      await fs.unlink(req.file.path).catch(console.error);
    }
    
    res.status(500).json({ 
      error: 'Internal server error',
      details: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
});

// Serve uploaded videos statically
// app.use('/uploads', express.static(join(__dirname, 'uploads')));
app.use(express.static('public'));


// Start server
const PORT = process.env.PORT || 5001;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
// -------------------------------------------------------------------------------------------------------------------------------
