// server.js
import express from 'express';
import cors from 'cors';
import { MongoClient } from 'mongodb';

const app = express();
app.use(cors());
app.use(express.json());

// MongoDB Connection URI and Database
const mongoURI = 'mongodb+srv://mk07521:L0kuOy5N0oqi94qS@videos.2fld2.mongodb.net/?retryWrites=true&w=majority&appName=Videos';
const client = new MongoClient(mongoURI);
const database = client.db('App_Videos');
const collection = database.collection('fs.files');

// Fetch videos by category
app.get('/api/videos/:category', async (req, res) => {
  const { category } = req.params;
  try {
    await client.connect();
    const videos = await collection
      .find({ category }) // Match category in MongoDB
      .toArray();
    res.json(videos);
  } catch (error) {
    console.error('Error fetching videos:', error);
    res.status(500).send('Internal Server Error');
  }
});

// Start server
const PORT = process.env.PORT || 5001;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
